// Local modules 

const output1 = require('./test3');
const output2 = require('./test4');
console.log(output1);
console.log(output1('Hello'));
console.log(output2);
console.log(output2.O1('hello sanjay'));
console.log(output2.val1);
console.log(output2.val2);
console.log(output2.val3);