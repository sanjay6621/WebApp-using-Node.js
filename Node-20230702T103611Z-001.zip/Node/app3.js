const a = 4
const b = 6
console.log(a,b,a+b)
console.log('%s',a)
console.log('hi sanjay tulabandula');
console.count('test' +a);
console.count('test' +a);
console.count('test' +a);
// console.clear();
console.log('hi sanjay');
console.warn('warn');
console.info('info');
console.table([{a:4 , b:2},{a:6 , b:3} ,{a:10 , b: 12}]);

//const first = process.argv[1];
//const second = process.argv[3];
//console.log('hi'+process.argv[0] +second);

