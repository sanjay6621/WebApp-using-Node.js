const url = "mongodb+srv://sanjay:Sanjay6621@cluster0.ghqoh.mongodb.net/myFirstDatabase?retryWrites=true&w=majority";
module.exports = url;