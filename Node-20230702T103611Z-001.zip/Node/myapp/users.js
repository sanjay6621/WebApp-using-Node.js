const myObj = {
    users: [
        {
            id: 1,
            name: "sanjay"
        },
        {
            id: 2,
            name: "yamini"
        },
        {
            id: 3,
            name: "latha"
        },

    ]
}

module.exports = myObj;

