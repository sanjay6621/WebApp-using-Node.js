const test1 = function(){
    console.log('test100');
}
const person ={
    first : 'yamini',
    last : 'tulabandula'
}


//test1();

//const test1 = "hello "; it gives an error

// console.log(module.filename); // module.filename for for loacation and path of filename

// module types

exports.test1 = test1;
exports.person = person;

