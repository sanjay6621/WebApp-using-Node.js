const test1 = function(){
    console.log('test100');
}
const person ={
    first : 'sanjay',
    last : 'tulabandula'
}


//test1();

//const test1 = "hello "; it gives an error

// console.log(module.filename); // module.filename for for loacation and path of filename

// module types

exports.A1 = test1;
exports.A2 = person;

