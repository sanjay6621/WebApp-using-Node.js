exports.output = {
    first : "sanjay",
    last : "tulabandula"
}

