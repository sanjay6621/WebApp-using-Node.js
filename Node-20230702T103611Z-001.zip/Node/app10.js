// switch statement examples

const val = 'zero';
 
switch(val){
case 'yes' : 
console.log('it was yes');
console.log('test')
break;
 case 'none ':
     case 'zero':
 console.log('was not yes or no');
 break;
case 'no' :
    console.log('it was no');
    break;
    default:
        console.log('none was found')
}