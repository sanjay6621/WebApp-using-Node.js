/*const num1 = 8883749;
const rem = num1 % 2;
console.log(rem);

if(rem){
    console.log( num1 + ' : was odd ');
}else{
console.log(num1 + ' :was even ');
    }

if(1){
    console.log('was true');
}else{
console.log('was false');
    }*/

   /* function checkOutput(val){
        let message ;
        let checkNum = 10;
    if(val > checkNum){
        message = val + ' was larger than  '+ checkNum;
    }
    else if (val == checkNum){
                 message = val + ' is equal to '+ checkNum ;
     } else{
    message = val + ' was lesser than ' + checkNum;
        }
        return message;
    }

    let counter = 3;
     let temp = (counter > 10) ? "true " : "false not greater"; // terinary operator which will be using onlyy in the java script
     console.log(temp)
    console.log(checkOutput(counter));
    counter++;
    counter+=8;
    console.log(checkOutput(counter));
    counter -= 2;
    console.log(checkOutput(counter));*/

const age = 15 ;
let message ;

let message1 = (age >=21 ?  " allow in " : " not allowed ")
console.log(message1);// using terinary operator

    if(age > 21){
message = "allow in";
    }
    else {
        message =  " not allowed ";
    }
    console.log(message);



    

