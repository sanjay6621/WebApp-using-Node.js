let counter = 10;
for (let i = 0; i< counter ; i++){
    console.log('value of i '+ i );
}

for ( let x = 10 ; x>0 ; x--){
    console.log('value of x '+ x);
}

 console.clear();

let y=0;
while (y<10){
    console.log('value of y '+ y );
    y++;
}

do{
    console.log('DO WHILE  of y '+ y );
    y++;
}

while(y<10);


