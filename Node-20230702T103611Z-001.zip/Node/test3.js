const output = function(message){
    console.log(`This is your message ${message}`)
    return message;
}

module.exports= output;