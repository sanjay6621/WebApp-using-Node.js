let a=5;
let b = "string 's'";
let c = 'string"s" ';
console.log(a,b,c);

let myNewValue = "test"; //no spaces
let one1 = "one ";//can't start with the number
let $_var = "test"; //can use $ or _

let boo = true; // boolean
console.log(typeof a);
console.log(typeof b);
console.log(typeof boo);
const newVarible = "hello";
console.log(newVarible);
//newVarible = "world";
//console.log(newVarible);
/*
{
    let newVarible = "hello";
    console.log(newVarible);
    newVarible = "world 2";
}
*/
{
    const newVarible = "world ";
}
console.log(newVarible);

const arr = ['hello ', 'world', 123 , true ];//arrays
console.log(arr);
const myobj = {"first ":"sanjay",last:"tulabandula",age : "none"};
console.log(myobj);//objects

let myStr = "hello";
console.log(typeof myStr);
myStr = 500;
myStr = "5 " + 5
console.log(typeof myStr);
console.log(myStr);//data types -> string to number and number to string 

