// javascript operators 

//const val = 100;  //or

/*let val = 100;
 val =  val + 1000;
val += 1;
val += 1;
val--;
val -= 500;
val = val*2;// val *= 2
val /= 3;
 console.log(401/2);
console.log(401%2);

console.log(3**2);

let val2 = 50
val2 = 50 % 10;
console.log(val2);

console.log(val*10);
console.log(val);

const first = "hello";
const second = "world";
console.log(first+ ' ' +second);*/


let a = "5";
let b =  5;
// comparison operators
  // const val4  = (a == b);//for checking the same values or not
 // const val5 = (a === b);// for checking the data type
let  val5 = (a === b);
      val5 = (a>=b);
      val5 = (a!== b);

 // console.log(val4);
 console.log(val5);

 // logical operators

    val = (true) && (false); // both true to be true 
   
   val = (false)||(false); // one  has to be  true to be true
  val = !(true);

 console.log(val);  



 
 

